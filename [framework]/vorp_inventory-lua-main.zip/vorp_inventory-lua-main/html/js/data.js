let isOpen = false;
let type = "normal";
let disabled = false;
let disabledFunction = null;
let ready4Action = true;
let checkxy;
let infoxy;
let customId = 0;
let houseId = 0;
let hideoutid = 0;
let clanid = 0;
let stealid = 0;
let Containerid = 0;
let horseid = 0;
let wagonid = 0;
let bankId = 0;
let secondaryCapacityAvailable = false;
let allplayerammo = [];
let ammolabels = [];
let isValidating = false; // Block other validation event when a validation prompt is already processing
let LANGUAGE = {};
let objToGive = {};
let geninfo;
let StoreId;
let LuaConfig = {};
// Define the ID object
