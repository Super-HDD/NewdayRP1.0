# RexshackGaming
- discord : https://discord.gg/eW3ADkf4Af
- youtube : https://www.youtube.com/channel/UCikEgGfXO-HCPxV5rYHEVbA
- github : https://github.com/Rexshack-RedM

# Dependancies
- rsg-core
- rsg-menu

# Installation
- ensure that the dependancies are added and started
- add rsg-cooking to your resources folder
- adjust the config.lua as required

# Starting the resource
- add the following to your server.cfg file : ensure rsg-cooking
