local Translations = {
    error = {
      you_dont_have_the_required_items = "您没有所需的物品!",
    },
    success = {
      cooking_finished = '烹饪完成',
    },
    primary = {
      campfire_put_out = '营火被扑灭',
      campfire_deployed = '营火已部署'
    },
    menu = {
      fish_steak = '鱼排',
      meat_steak = '肉排',
      cooking_menu = '🥩 | 烹饪菜单',
      close_menu = '❌ | 关闭菜单',
    },
    commands = {
      deploy_campfire = '部署篝火',
    },
    progressbar = {
      cooking_a = '烹饪一个 ',
    },
    label = {
      open_cooking_menu = '打开烹饪菜单',
      campfire_put_out='扑灭营火'
    }
}

Lang = Locale:new({
    phrases = Translations,
    warnOnMissing = true
})
