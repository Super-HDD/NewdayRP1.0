local QBCore = exports['qb-core']:GetCoreObject()

local CampfireCount=0

-- use campfire command
QBCore.Commands.Add("campfire", Lang:t('commands.deploy_campfire'), {}, false, function(source)
    local src = source
    TriggerClientEvent('qb-cooking:client:setupcampfire', src)
end)

-- use campfire
QBCore.Functions.CreateUseableItem("campfire", function(source, item)
    local src = source
    TriggerClientEvent('qb-cooking:client:setupcampfire', src, item.name)
end)

-- check player has the ingredients
QBCore.Functions.CreateCallback('qb-cooking:server:checkingredients', function(source, cb, ingredients)
    local src = source
    local hasItems = false
    local icheck = 0
    local Player = QBCore.Functions.GetPlayer(src)
    for k, v in pairs(ingredients) do
        if Player.Functions.GetItemByName(v.item) and Player.Functions.GetItemByName(v.item).amount >= v.amount then
            icheck = icheck + 1
            if icheck == #ingredients then
                cb(true)
            end
        else
            TriggerClientEvent('QBCore:Notify', src, Lang:t('error.you_dont_have_the_required_items'), 'error')
            cb(false)
            return
        end
    end
end)

-- finish cooking
RegisterServerEvent('qb-cooking:server:finishcooking')
AddEventHandler('qb-cooking:server:finishcooking', function(ingredients, receive, giveamount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    -- remove ingredients
    for k, v in pairs(ingredients) do
        if Config.Debug == true then
            print(v.item)
            print(v.amount)
        end
        Player.Functions.RemoveItem(v.item, v.amount)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[v.item], "remove")
    end
    -- add cooked item
    Player.Functions.AddItem(receive, giveamount)
    TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[receive], "add")
    TriggerClientEvent('QBCore:Notify', src, Lang:t('success.cooking_finished'), 'success')
end)

local function RemoveCampfire(FireProp,CookGrillProp)
    local ped=QBCore.Functions.GetPlayer()
    TaskStartScenarioInPlace(ped, GetHashKey('WORLD_HUMAN_CROUCH_INSPECT'), -1, true, false, false, false)
    Wait(6000)
    ClearPedTasks(ped)
    SetEntityAsMissionEntity(FireProp)
    DeleteObject(FireProp)
    SetEntityAsMissionEntity(CookGrillProp)
    DeleteObject(CookGrillProp)
    QBCore.Functions.Notify(Lang:t('primary.campfire_put_out'), 'primary')
end

RegisterServerEvent('qb-cooking:server:create-campfire-target',function(fire,grill)
    TriggerClientEvent('qb-cooking:client:create-campfire-target',-1,fire,grill,CampfireCount)
end)
