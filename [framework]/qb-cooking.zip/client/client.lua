local QBCore = exports['qb-core']:GetCoreObject()
local campfire = false
local fire
local cookgrill

------------------------------------------------------------------------------------------------------

-- exports['qb-target']:AddTargetModel(Config.CampfireProps, {
--     options = {
--         {
--             type = "client",
--             event = 'qb-cooking:client:cookmenu',
--             icon = "far fa-eye",
--             label = Lang:t('label.open_cooking_menu'),
--             distance = 3.0
--         },
--         {
--             type = "client",
--             event = 'qb-cooking:client:delete-campfire',
--             icon = "far fa-eye",
--             label = Lang:t('label.campfire_put_out'),
--             distance = 3.0
--         }
--     }
-- })

------------------------------------------------------------------------------------------------------
local function RemoveCampfire(ped,FireProp,CookGrillProp)
    print(FireProp)
    TaskStartScenarioInPlace(ped, GetHashKey('WORLD_HUMAN_CROUCH_INSPECT'), -1, true, false, false, false)
    Wait(6000)
    ClearPedTasks(ped)
    SetEntityAsMissionEntity(FireProp)
    DeleteObject(FireProp)
    SetEntityAsMissionEntity(CookGrillProp)
    DeleteObject(CookGrillProp)
    QBCore.Functions.Notify(Lang:t('primary.campfire_put_out'), 'primary')
end

RegisterNetEvent('qb-cooking:server:create-campfire-target',function(args)
    print(QBCore.Debug(args))
    RemoveCampfire(PlayerPedId(),args[1],args[2])
end)

-- setup campfire / use campfire to setup and put out
RegisterNetEvent('qb-cooking:client:setupcampfire')
AddEventHandler('qb-cooking:client:setupcampfire', function()
    local ped = PlayerPedId()
    -- if campfire == true then
    --     TaskStartScenarioInPlace(ped, GetHashKey('WORLD_HUMAN_CROUCH_INSPECT'), -1, true, false, false, false)
    --     Wait(6000)
    --     ClearPedTasks(ped)
    --     SetEntityAsMissionEntity(fire)
    --     DeleteObject(fire)
    --     SetEntityAsMissionEntity(cookgrill)
    --     DeleteObject(cookgrill)
    --     QBCore.Functions.Notify(Lang:t('primary.campfire_put_out'), 'primary')
    --     campfire = false
    -- elseif campfire == false then
        TaskStartScenarioInPlace(ped, GetHashKey('WORLD_HUMAN_CROUCH_INSPECT'), -1, true, false, false, false)
        Wait(6000)
        ClearPedTasks(ped)
        local x,y,z = table.unpack(GetOffsetFromEntityInWorldCoords(PlayerPedId(), 0.0, 0.75, -1.55))
        local prop = CreateObject(GetHashKey("p_campfire05x"), x, y+1, z, true, false, true)
        local prop2 = CreateObject(GetHashKey("p_cookgrate01x"), x, y+1, z, true, false, true)
        SetEntityHeading(prop, GetEntityHeading(PlayerPedId()))
        SetEntityHeading(prop2, GetEntityHeading(PlayerPedId()))
        PlaceObjectOnGroundProperly(prop)
        PlaceObjectOnGroundProperly(prop2)
        fire = prop
        cookgrill = prop2
        QBCore.Functions.Notify(Lang:t('primary.campfire_deployed'), 'primary')
        campfire = true
       TriggerServerEvent('qb-cooking:server:create-campfire-target',fire,cookgrill)
    -- end
end, false)

------------------------------------------------------------------------------------------------------

-- cook menu
RegisterNetEvent('qb-cooking:client:cookmenu', function()
    cookMenu = {}
    cookMenu = {
        {
            header = Lang:t('menu.cooking_menu'),
            isMenuHeader = true,
        },
    }
    for k, v in pairs(Config.Recipes) do
        local item = {}
        local text = ""
        for k, v in pairs(v.ingredients) do
            text = text .. "- " .. QBCore.Shared.Items[v.item].label .. ": " .. v.amount .. "x <br>"
        end
        cookMenu[#cookMenu + 1] = {
            header = k,
            txt = text,
            params = {
                event = 'qb-cooking:client:checkingredients',
                args = {
                    name = v.name,
                    item = k,
                    cooktime = v.cooktime,
                    receive = v.receive,
                    giveamount = v.giveamount
                }
            }
        }
    end
    cookMenu[#cookMenu + 1] = {
        header = Lang:t('menu.close_menu'),
        txt = '',
        params = {
            event = 'qb-menu:closeMenu',
        }
    }
    exports['qb-menu']:openMenu(cookMenu)
end)

RegisterNetEvent('qb-cooking:client:create-campfire-target',function(FireProp,GrillProp)
    -- exports['qb-target']:AddTargetEntity({FireProp,GrillProp}, {
    --     options = {
    --         {
    --             type = "client",
    --             event = 'qb-cooking:client:cookmenu',
    --             icon = "far fa-eye",
    --             label = Lang:t('label.open_cooking_menu'),
    --             distance = 3.0
    --         },
    --         {
    --             action=function()RemoveCampfire(PlayerPedId(),FireProp,GrillProp) end,
    --             icon = "far fa-eye",
    --             label = Lang:t('label.campfire_put_out'),
    --             distance = 3.0
    --         }
    --     }
    -- })
    exports.ox_target:addEntity(FireProp, {
        options = {
            {
                type = "client",
                event = 'qb-cooking:client:cookmenu',
                icon = "far fa-eye",
                label = Lang:t('label.open_cooking_menu'),
                distance = 3.0
            },
            {
                action=function()RemoveCampfire(PlayerPedId(),FireProp,GrillProp) end,
                icon = "far fa-eye",
                label = Lang:t('label.campfire_put_out'),
                distance = 3.0
            }
        }
    })
end)

------------------------------------------------------------------------------------------------------

-- check player has the ingredients to cook item
RegisterNetEvent('qb-cooking:client:checkingredients', function(data)
    QBCore.Functions.TriggerCallback('qb-cooking:server:checkingredients', function(hasRequired)
    if (hasRequired) then
        if Config.Debug == true then
            print("passed")
        end
        TriggerEvent('qb-cooking:cookmeal', data.name, data.item, tonumber(data.cooktime), data.receive, data.giveamount)
    else
        if Config.Debug == true then
            print("failed")
        end
        return
    end
    end, Config.Recipes[data.item].ingredients)
end)

-- do cooking
RegisterNetEvent('qb-cooking:cookmeal', function(name, item, cooktime, receive, giveamount)
    local ingredients = Config.Recipes[item].ingredients
    QBCore.Functions.Progressbar('cook-meal', Lang:t('progressbar.cooking_a')..name, cooktime, false, true, {
        disableMovement = true,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() -- Done
        TriggerServerEvent('qb-cooking:server:finishcooking', ingredients, receive, giveamount)
    end)
end)

------------------------------------------------------------------------------------------------------
