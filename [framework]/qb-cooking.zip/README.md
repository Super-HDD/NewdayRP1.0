# RexshackGaming
- discord : https://discord.gg/s5uSk56B65
- github : https://github.com/Rexshack-RedM

# Dependancies
- qb-core
- qb-menu

# Installation
- ensure that the dependancies are added and started
- add qb-cooking to your resources folder
- adjust the config.lua as required

# Starting the resource
- add the following to your server.cfg file : ensure qb-cooking
