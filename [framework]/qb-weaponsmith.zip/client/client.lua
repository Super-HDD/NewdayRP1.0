local QBCore = exports['qb-core']:GetCoreObject()
local isLoggedIn = false
local PlayerData = {}
local currentjob
local jobaccess

-----------------------------------------------------------------------------------

AddEventHandler('QBCore:Client:OnPlayerLoaded', function()
    isLoggedIn = true
    PlayerData = QBCore.Functions.GetPlayerData()
    currentjob = PlayerData.job.name
end)

RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
    isLoggedIn = false
    PlayerData = {}
end)

RegisterNetEvent('QBCore:Client:OnJobUpdate', function(JobInfo)
    PlayerData.job = JobInfo
    currentjob = PlayerData.job.name
end)

-----------------------------------------------------------------------------------

-- prompts and blips
CreateThread(function()
    for index, v in pairs(Config.WeaponCraftingPoint) do
        exports['qb-core']:createPrompt(v.prompt, v.coords, QBCore.Shared.Keybinds['J'], Lang:t('menu.open') .. v.name, {
            type = 'client',
            event = 'qb-weaponsmiteh:client:mainmenu',
            args = { v.job },
        })   
    end
end)

-----------------------------------------------------------------------------------

-- weaponsmith menu
RegisterNetEvent('qb-weaponsmiteh:client:mainmenu', function(jobaccess)
    if currentjob == jobaccess then
        exports['qb-menu']:openMenu({
            {
                header =  Lang:t('menu.weapon_crafting'),
                isMenuHeader = true,
            },
            {
                header = Lang:t('menu.weapon_parts_crafting'),
                txt = "",
                icon = "fas fa-tools",
                params = {
                    event = 'qb-weaponsmiteh:client:partsmenu',
                    isServer = false,
                }
            },
            {
                header = Lang:t('menu.weapon_crafting'),
                txt = "",
                icon = "fas fa-tools",
                params = {
                    event = 'qb-weaponsmiteh:client:weaponmenu',
                    isServer = false,
                }
            },
            {
                header = Lang:t('menu.tools_crafting'),
                txt = "",
                icon = "fas fa-tools",
                params = {
                    event = 'qb-weaponsmiteh:client:toolsmenu',
                    isServer = false,
                }
            },
            {
                header = Lang:t('menu.weaponsmith_storage'),
                txt = "",
                icon = "fas fa-box",
                params = {
                    event = 'qb-weaponsmiteh:client:storage',
                    isServer = false,
                    args = {},
                }
            },
            {
                header = Lang:t('menu.job_management'),
                txt = "",
                icon = "fas fa-user-circle",
                params = {
                    event = 'qb-bossmenu:client:OpenMenu',
                    isServer = false,
                    args = {},
                }
            },
            {
                header = Lang:t('menu.close_menu'),
                txt = '',
                params = {
                    event = 'qb-menu:closeMenu',
                }
            },
        })
    else
        QBCore.Functions.Notify(Lang:t('error.you_are_not_authorised'), 'error')
    end
end)

-- parts menu
RegisterNetEvent('qb-weaponsmiteh:client:partsmenu', function()
    partsMenu = {}
    partsMenu = {
        {
            header = Lang:t('menu.weapon_parts_crafting'),
            isMenuHeader = true,
        },
    }
    local item = {}
    for k, v in pairs(Config.WeaponPartsCrafting) do
        partsMenu[#partsMenu + 1] = {
            header = v.lable,
            txt = text,
            icon = 'fas fa-cog',
            params = {
                event = 'qb-weaponsmiteh:client:partscheckitems',
                args = {
                    name = v.name,
                    lable = v.lable,
                    item = k,
                    crafttime = v.crafttime,
                    receive = v.receive
                }
            }
        }
    end
    partsMenu[#partsMenu + 1] = {
        header = Lang:t('menu.close_menu'),
        txt = '',
        params = {
            event = 'qb-menu:closeMenu',
        }
    }
    exports['qb-menu']:openMenu(partsMenu)
end)

-- weaponsmith weapon menu
RegisterNetEvent('qb-weaponsmiteh:client:weaponmenu', function()
    exports['qb-menu']:openMenu({
        {
            header = Lang:t('menu.weapon_crafting'),
            isMenuHeader = true,
        },
        {
            header = Lang:t('menu.revolver_crafting'),
            txt = "",
            icon = "fas fa-tools",
            params = {
                event = 'qb-weaponsmiteh:client:revlovermenu',
                isServer = false,
            }
        },
        {
            header = Lang:t('menu.pistol_crafting'),
            txt = "",
            icon = "fas fa-tools",
            params = {
                event = 'qb-weaponsmiteh:client:pistolmenu',
                isServer = false,
            }
        },
        {
            header = Lang:t('menu.repeater_crafting'),
            txt = "",
            icon = "fas fa-tools",
            params = {
                event = 'qb-weaponsmiteh:client:repeatermenu',
                isServer = false,
            }
        },
        {
            header = Lang:t('menu.rifle_crafting'),
            txt = "",
            icon = "fas fa-tools",
            params = {
                event = 'qb-weaponsmiteh:client:riflemenu',
                isServer = false,
            }
        },
        {
            header = Lang:t('menu.shotgun_crafting'),
            txt = "",
            icon = "fas fa-tools",
            params = {
                event = 'qb-weaponsmiteh:client:shotgunmenu',
                isServer = false,
            }
        },
        {
            header = 'menu.tools_crafting',
            txt = "",
            icon = "fas fa-tools",
            params = {
                event = 'qb-weaponsmiteh:client:toolsmenu',
                isServer = false,
            }
        },
       
    })
end)

-- revlover menu
RegisterNetEvent('qb-weaponsmiteh:client:revlovermenu', function()
    revloverMenu = {}
    revloverMenu = {
        {
            header = Lang:t('menu.revolver_crafting'),
            isMenuHeader = true,
        },
    }
    local item = {}
    for k, v in pairs(Config.RevloverCrafting) do
        revloverMenu[#revloverMenu + 1] = {
            header = v.lable,
            txt = '',
            icon = 'fas fa-cog',
            params = {
                event = 'qb-weaponsmiteh:client:checkrevloveritems',
                args = {                
                    name = v.name,
                    lable = v.lable,
                    item = k,
                    crafttime = v.crafttime,
                    receive = v.receive
                }
            }
        }
    end
    revloverMenu[#revloverMenu + 1] = {
        header = Lang:t('menu.close_menu'),
        txt = '',
        params = {
            event = 'qb-menu:closeMenu',
        }
    }
    exports['qb-menu']:openMenu(revloverMenu)
end)

-- pistol menu
RegisterNetEvent('qb-weaponsmiteh:client:pistolmenu', function()
    pistolMenu = {}
    pistolMenu = {
        {
            header =Lang:t('menu.pistol_crafting'),
            isMenuHeader = true,
        },
    }
    local item = {}
    for k, v in pairs(Config.PistolCrafting) do
        pistolMenu[#pistolMenu + 1] = {
            header = v.lable,
            txt = '',
            icon = 'fas fa-cog',
            params = {
                event = 'qb-weaponsmiteh:client:checkpistolitems',
                args = {                
                    name = v.name,
                    lable = v.lable,
                    item = k,
                    crafttime = v.crafttime,
                    receive = v.receive
                }
            }
        }
    end
    pistolMenu[#pistolMenu + 1] = {
        header = Lang:t('menu.close_menu'),
        txt = '',
        params = {
            event = 'qb-menu:closeMenu',
        }
    }
    exports['qb-menu']:openMenu(pistolMenu)
end)

-- repeater menu
RegisterNetEvent('qb-weaponsmiteh:client:repeatermenu', function()
    repeaterMenu = {}
    repeaterMenu = {
        {
            header = Lang:t('menu.repeater_crafting'),
            isMenuHeader = true,
        },
    }
    local item = {}
    for k, v in pairs(Config.RepeaterCrafting) do
        repeaterMenu[#repeaterMenu + 1] = {
            header = v.lable,
            txt = '',
            icon = 'fas fa-cog',
            params = {
                event = 'qb-weaponsmiteh:client:checkrepeateritems',
                args = {                
                    name = v.name,
                    lable = v.lable,
                    item = k,
                    crafttime = v.crafttime,
                    receive = v.receive
                }
            }
        }
    end
    repeaterMenu[#repeaterMenu + 1] = {
        header = Lang:t('menu.close_menu'),
        txt = '',
        params = {
            event = 'qb-menu:closeMenu',
        }
    }
    exports['qb-menu']:openMenu(repeaterMenu)
end)

-- rifle menu
RegisterNetEvent('qb-weaponsmiteh:client:riflemenu', function()
    rifleMenu = {}
    rifleMenu = {
        {
            header = Lang:t('menu.rifle_crafting'),
            isMenuHeader = true,
        },
    }
    local item = {}
    for k, v in pairs(Config.RifleCrafting) do
        rifleMenu[#rifleMenu + 1] = {
            header = v.lable,
            txt = '',
            icon = 'fas fa-cog',
            params = {
                event = 'qb-weaponsmiteh:client:checkrifleitems',
                args = {                
                    name = v.name,
                    lable = v.lable,
                    item = k,
                    crafttime = v.crafttime,
                    receive = v.receive
                }
            }
        }
    end
    rifleMenu[#rifleMenu + 1] = {
        header = Lang:t('menu.close_menu'),
        txt = '',
        params = {
            event = 'qb-menu:closeMenu',
        }
    }
    exports['qb-menu']:openMenu(rifleMenu)
end)

-- shotgun menu
RegisterNetEvent('qb-weaponsmiteh:client:shotgunmenu', function()
    shotgunMenu = {}
    shotgunMenu = {
        {
            header = Lang:t('menu.shotgun_crafting'),
            isMenuHeader = true,
        },
    }
    local item = {}
    for k, v in pairs(Config.ShotgunCrafting) do
        shotgunMenu[#shotgunMenu + 1] = {
            header = v.lable,
            txt = '',
            icon = 'fas fa-cog',
            params = {
                event = 'qb-weaponsmiteh:client:checkshotgunitems',
                args = {                
                    name = v.name,
                    lable = v.lable,
                    item = k,
                    crafttime = v.crafttime,
                    receive = v.receive
                }
            }
        }
    end
    shotgunMenu[#shotgunMenu + 1] = {
        header = Lang:t('menu.close_menu'),
        txt = '',
        params = {
            event = 'qb-menu:closeMenu',
        }
    }
    exports['qb-menu']:openMenu(shotgunMenu)
end)

-- 工具菜单
RegisterNetEvent('qb-weaponsmiteh:client:toolsmenu', function()
    toolsMenu = {}
    toolsMenu = {
        {
            header = Lang:t('menu.tools_crafting'),
            isMenuHeader = true,
        },
    }
    local item = {}
    for k, v in pairs(Config.ToolsCrafting) do
        toolsMenu[#toolsMenu + 1] = {
            header = v.lable,
            txt = '',
            icon = 'fas fa-cog',
            params = {
                event = 'qb-weaponsmiteh:client:check-tools-items',
                args = {                
                    name = v.name,
                    lable = v.lable,
                    item = k,
                    crafttime = v.crafttime,
                    receive = v.receive
                }
            }
        }
    end
    -- toolsMenu[#toolsMenu + 1] = {
    --     header = Lang:t('menu.close_menu'),
    --     txt = '',
    --     params = {
    --         event = 'qb-menu:closeMenu',
    --     }
    -- }
    exports['qb-menu']:openMenu(toolsMenu)
end)

------------------------------------------------------------------------------------------------------开始制作

-- parts crafting : check player has the items
RegisterNetEvent('qb-weaponsmiteh:client:partscheckitems', function(data)
    QBCore.Functions.TriggerCallback('qb-weaponsmiteh:server:checkitems', function(hasRequired)
    if (hasRequired) then
        if Config.Debug == true then
            print("passed")
        end
        TriggerEvent('qb-weaponsmiteh:client:startpartscrafting', data.name, data.lable, data.item, tonumber(data.crafttime), data.receive)
    else
        if Config.Debug == true then
            print("failed")
        end
        return
    end
    end, Config.WeaponPartsCrafting[data.item].craftitems)
end)

-- revovler crafting : check player has the items
RegisterNetEvent('qb-weaponsmiteh:client:checkrevloveritems', function(data)
    QBCore.Functions.TriggerCallback('qb-weaponsmiteh:server:checkitems', function(hasRequired)
    if (hasRequired) then
        if Config.Debug == true then
            print("passed")
        end
        TriggerEvent('qb-weaponsmiteh:client:startrevlovercrafting', data.name, data.lable, data.item, tonumber(data.crafttime), data.receive)
    else
        if Config.Debug == true then
            print("failed")
        end
        return
    end
    end, Config.RevloverCrafting[data.item].craftitems)
end)

-- pistol crafting : check player has the items
RegisterNetEvent('qb-weaponsmiteh:client:checkpistolitems', function(data)
    QBCore.Functions.TriggerCallback('qb-weaponsmiteh:server:checkitems', function(hasRequired)
    if (hasRequired) then
        if Config.Debug == true then
            print("passed")
        end
        TriggerEvent('qb-weaponsmiteh:client:startpistolcrafting', data.name, data.lable, data.item, tonumber(data.crafttime), data.receive)
    else
        if Config.Debug == true then
            print("failed")
        end
        return
    end
    end, Config.PistolCrafting[data.item].craftitems)
end)

-- repeater crafting : check player has the items
RegisterNetEvent('qb-weaponsmiteh:client:checkrepeateritems', function(data)
    QBCore.Functions.TriggerCallback('qb-weaponsmiteh:server:checkitems', function(hasRequired)
    if (hasRequired) then
        if Config.Debug == true then
            print("passed")
        end
        TriggerEvent('qb-weaponsmiteh:client:startrepeatercrafting', data.name, data.lable, data.item, tonumber(data.crafttime), data.receive)
    else
        if Config.Debug == true then
            print("failed")
        end
        return
    end
    end, Config.RepeaterCrafting[data.item].craftitems)
end)

-- rifle crafting : check player has the items
RegisterNetEvent('qb-weaponsmiteh:client:checkrifleitems', function(data)
    QBCore.Functions.TriggerCallback('qb-weaponsmiteh:server:checkitems', function(hasRequired)
    if (hasRequired) then
        if Config.Debug == true then
            print("passed")
        end
        TriggerEvent('qb-weaponsmiteh:client:startriflecrafting', data.name, data.lable, data.item, tonumber(data.crafttime), data.receive)
    else
        if Config.Debug == true then
            print("failed")
        end
        return
    end
    end, Config.RifleCrafting[data.item].craftitems)
end)

-- shotgun crafting : check player has the items
RegisterNetEvent('qb-weaponsmiteh:client:checkshotgunitems', function(data)
    QBCore.Functions.TriggerCallback('qb-weaponsmiteh:server:checkitems', function(hasRequired)
    if (hasRequired) then
        if Config.Debug == true then
            print("passed")
        end
        TriggerEvent('qb-weaponsmiteh:client:startshotguncrafting', data.name, data.lable, data.item, tonumber(data.crafttime), data.receive)
    else
        if Config.Debug == true then
            print("failed")
        end
        return
    end
    end, Config.ShotgunCrafting[data.item].craftitems)
end)

-- gongju crafting : check player has the items
RegisterNetEvent('qb-weaponsmiteh:client:check-tools-items', function(data)
    QBCore.Functions.TriggerCallback('qb-weaponsmiteh:server:checkitems', function(hasRequired)
    if (hasRequired) then
        if Config.Debug == true then
            print("passed")
        end
        TriggerEvent('qb-weaponsmiteh:client:start-tools-crafting', data.name, data.lable, data.item, tonumber(data.crafttime), data.receive)
    else
        if Config.Debug == true then
            print("failed")
        end
        return
    end
    end, Config.ToolsCrafting[data.item].craftitems)
end)

------------------------------------------------------------------------------------------------------

-- start parts crafting
RegisterNetEvent('qb-weaponsmiteh:client:startpartscrafting', function(name, lable, item, crafttime, receive)
    local craftitems = Config.WeaponPartsCrafting[item].craftitems
    QBCore.Functions.Progressbar('craft-parts', Lang:t('progressbar.crafting_a')..lable, crafttime, false, true, {
        disableMovement = true,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() -- Done
        TriggerServerEvent('qb-weaponsmiteh:server:finishcrafting', craftitems, receive)
    end)
end)

-- start revlover crafting
RegisterNetEvent('qb-weaponsmiteh:client:startrevlovercrafting', function(name, lable, item, crafttime, receive)
    local craftitems = Config.RevloverCrafting[item].craftitems
    QBCore.Functions.Progressbar('craft-revlover', Lang:t('progressbar.crafting_a')..lable, crafttime, false, true, {
        disableMovement = true,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() -- Done
        TriggerServerEvent('qb-weaponsmiteh:server:finishcrafting', craftitems, receive)
    end)
end)

-- start pistol crafting
RegisterNetEvent('qb-weaponsmiteh:client:startpistolcrafting', function(name, lable, item, crafttime, receive)
    local craftitems = Config.PistolCrafting[item].craftitems
    QBCore.Functions.Progressbar('craft-pistol', Lang:t('progressbar.crafting_a')..lable, crafttime, false, true, {
        disableMovement = true,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() -- Done
        TriggerServerEvent('qb-weaponsmiteh:server:finishcrafting', craftitems, receive)
    end)
end)

-- start repeater crafting
RegisterNetEvent('qb-weaponsmiteh:client:startrepeatercrafting', function(name, lable, item, crafttime, receive)
    local craftitems = Config.RepeaterCrafting[item].craftitems
    QBCore.Functions.Progressbar('craft-repeater', Lang:t('progressbar.crafting_a')..lable, crafttime, false, true, {
        disableMovement = true,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() -- Done
        TriggerServerEvent('qb-weaponsmiteh:server:finishcrafting', craftitems, receive)
    end)
end)

-- start rifle crafting
RegisterNetEvent('qb-weaponsmiteh:client:startriflecrafting', function(name, lable, item, crafttime, receive)
    local craftitems = Config.RifleCrafting[item].craftitems
    QBCore.Functions.Progressbar('craft-rifle', Lang:t('progressbar.crafting_a')..lable, crafttime, false, true, {
        disableMovement = true,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() -- Done
        TriggerServerEvent('qb-weaponsmiteh:server:finishcrafting', craftitems, receive)
    end)
end)

-- start shotgun crafting
RegisterNetEvent('qb-weaponsmiteh:client:startshotguncrafting', function(name, lable, item, crafttime, receive)
    local craftitems = Config.ShotgunCrafting[item].craftitems
    QBCore.Functions.Progressbar('craft-shotgun', Lang:t('progressbar.crafting_a')..lable, crafttime, false, true, {
        disableMovement = true,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() -- Done
        TriggerServerEvent('qb-weaponsmiteh:server:finishcrafting', craftitems, receive)
    end)
end)
-- 开始制作工具
RegisterNetEvent('qb-weaponsmiteh:client:start-tools-crafting', function(name, lable, item, crafttime, receive)
    local craftitems = Config.ToolsCrafting[item].craftitems
    QBCore.Functions.Progressbar('craft-shotgun', Lang:t('progressbar.crafting_a')..lable, crafttime, false, true, {
        disableMovement = true,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() -- Done
        TriggerServerEvent('qb-weaponsmiteh:server:finishcrafting', craftitems, receive)
    end)
end)

-----------------------------------------------------------------------------------

RegisterNetEvent('qb-weaponsmiteh:client:storage', function()
    local playerjob = PlayerData.job.name
    if playerjob == currentjob then
        TriggerServerEvent("inventory:server:OpenInventory", "stash", currentjob, {
            maxweight = Config.StorageMaxWeight,
            slots = Config.StorageMaxSlots,
        })
        TriggerEvent("inventory:client:SetCurrentStash", currentjob)
    end
end)

-----------------------------------------------------------------------------------

-- clean/inspect weapon
RegisterNetEvent('qb-weaponsmiteh:client:serviceweapon', function(item, amount)
    local playerjob = PlayerData.job.name
    if playerjob == currentjob then
        local ped = PlayerPedId()
        local cloth = CreateObject(`s_balledragcloth01x`, GetEntityCoords(PlayerPedId()), false, true, false, false, true)
        local PropId = `CLOTH`
        local actshort = `SHORTARM_CLEAN_ENTER`
        local actlong = `LONGARM_CLEAN_ENTER`
        local retval, weaponHash = GetCurrentPedWeapon(PlayerPedId(), false, weaponHash, false)
        local model = GetWeapontypeGroup(weaponHash)
        local object = GetObjectIndexFromEntityIndex(GetCurrentPedWeaponEntityIndex(PlayerPedId(), 0))
        if Config.Debug == true then
            print("Weapon Group --> "..model)
            print("Weapon Hash --> "..weaponHash)        
        end
        if weaponHash ~= `WEAPON_UNARMED` then
            if model == 416676503 or model == -1101297303 then
                Citizen.InvokeNative(0x72F52AA2D2B172CC,  PlayerPedId(), "", cloth, PropId, actshort, 1, 0, -1.0) -- TaskItemInteraction_2
                Wait(15000)
                Citizen.InvokeNative(0xA7A57E89E965D839, object, 0.0, false) -- SetWeaponDegradation
                Citizen.InvokeNative(0xE22060121602493B, object, 0.0, false) -- SetWeaponDamage
                Citizen.InvokeNative(0x812CE61DEBCAB948, object, 0.0, false) -- SetWeaponDirt
                Citizen.InvokeNative(0xA9EF4AD10BDDDB57, object, 0.0, false) -- SetWeaponSoot
                QBCore.Functions.Notify( Lang:t('success.weapon_cleaned'), 'success')
            else
                Citizen.InvokeNative(0x72F52AA2D2B172CC,  PlayerPedId(), "", cloth, PropId, actlong, 1, 0, -1.0) -- TaskItemInteraction_2 
                Wait(15000)
                Citizen.InvokeNative(0xA7A57E89E965D839, object, 0.0, false) -- SetWeaponDegradation
                Citizen.InvokeNative(0xE22060121602493B, object, 0.0, false) -- SetWeaponDamage
                Citizen.InvokeNative(0x812CE61DEBCAB948, object, 0.0, false) -- SetWeaponDirt
                Citizen.InvokeNative(0xA9EF4AD10BDDDB57, object, 0.0, false) -- SetWeaponSoot
                QBCore.Functions.Notify(Lang:t('success.weapon_cleaned'), 'success')
            end
        else
            QBCore.Functions.Notify(Lang:t('error.you_must_be_holding_weapon'), 'error')
        end
    else
        QBCore.Functions.Notify(Lang:t('error.you_are_not_authorised'), 'error')
    end
end)

-----------------------------------------------------------------------------------
