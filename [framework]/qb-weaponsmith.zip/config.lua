Config = {}

-- debug
Config.Debug = true

-- settings
Config.StorageMaxWeight = 4000000
Config.StorageMaxSlots = 1000

-- blip settings


Config.WeaponCraftingPoint = {

    {   -- 圣丹尼斯武器铺
        name = '圣丹尼斯红色左轮枪械铺', 
        prompt = 'weaponsmith-2',
        job = 'stdenisweaponsmith',
        coords = vector3(2709.7432, -1285.9431, 49.5804), 
        showblip = true, 
        showmarker = true
    },

    {   -- 瓦伦丁武器铺
    name = '瓦伦丁罗兰小子枪械铺', 
    prompt = 'weaponsmith-1',
    job = 'valweaponsmith',
    coords = vector3(-277.2185, 779.09729, 119.50399), 
    showblip = true, 
    showmarker = true
    },

    {   -- 罗德武器铺
    name = '罗德镇枪械铺', 
    prompt = 'weaponsmith-3',
    job = 'rhoweaponsmith',
    coords = vector3(1327.06, -1322.06, 77.89), 
    showblip = true, 
    showmarker = true
    },

    {   -- 罗德武器铺
    name = '黑水镇枪械铺', 
    prompt = 'weaponsmith-4',
    job = 'blaweaponsmith',
    coords = vector3(-829.9905, -1276.6718, 43.7331), 
    showblip = true, 
    showmarker = true
    },

    


}

Config.WeaponPartsCrafting = {

    -- base weapon items
    ['trigger'] = {
        name = 'trigger',
        lable = '扳机',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'steel', amount = 5 },
        },
        receive = 'trigger'
    },
    
    ['hammer'] = {
        name = 'hammer',
        lable = '气锤',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'steel', amount = 5 },
        },
        receive = 'hammer'
    },
    
    ['barrel'] = {
        name = 'barrel',
        lable = '枪管',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'steel', amount = 5 },
        },
        receive = 'barrel'
    },
    
    ['spring'] = {
        name = 'spring',
        lable = '弹簧',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'steel', amount = 5 },
        },
        receive = 'spring'
    },
    
    ['frame'] = {
        name = 'frame',
        lable = '框架',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'steel', amount = 5 },
        },
        receive = 'frame'
    },

    ['grip'] = {
        name = 'grip',
        lable = '握把',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'steel', amount = 5 },
            [2] = { item = 'wood', amount = 5 },
        },
        receive = 'grip'
    },

    ['cylinder'] = {
        name = 'cylinder',
        lable = '气缸',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'steel', amount = 5 },
        },
        receive = 'cylinder'
    },
    
}

Config.RevloverCrafting = {
    
    -- 手枪制作
    ['weapon_revolver_cattleman'] = {
        name = 'weapon_revolver_cattleman',
        lable = '牛仔左轮',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'trigger',  amount = 1 },
            [2] = { item = 'hammer',   amount = 1 },
            [3] = { item = 'barrel',   amount = 1 },
            [4] = { item = 'frame',    amount = 1 },
            [5] = { item = 'grip',     amount = 1 },
            [6] = { item = 'cylinder', amount = 1 },
            
        },
        receive = 'weapon_revolver_cattleman'
    },

    ['weapon_revolver_cattleman_mexican'] = {
        name = 'weapon_revolver_cattleman_mexican',
        lable = '墨西哥牛仔左轮',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'trigger',  amount = 1 },
            [2] = { item = 'hammer',   amount = 1 },
            [3] = { item = 'barrel',   amount = 1 },
            [4] = { item = 'frame',    amount = 1 },
            [5] = { item = 'grip',     amount = 1 },
            [6] = { item = 'cylinder', amount = 1 },
            
        },
        receive = 'weapon_revolver_cattleman_mexican'
    },

    ['weapon_pistol_volcanic'] = {
        name = 'weapon_pistol_volcanic',
        lable = '火山手枪',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'trigger',  amount = 1 },
            [2] = { item = 'hammer',   amount = 1 },
            [3] = { item = 'barrel',   amount = 1 },
            [4] = { item = 'frame',    amount = 1 },
            [5] = { item = 'grip',     amount = 1 },
            [6] = { item = 'cylinder', amount = 1 },
            
        },
        receive = 'weapon_pistol_volcanic'
    },
    
}

Config.PistolCrafting = {
    
    -- 手枪制作
   
}

Config.RepeaterCrafting = {
    
    -- 子弹制作
    ['ammo_repeater'] = {
        name = 'ammo_repeater',
        lable = '连发步枪子弹 (N)',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'wood',  amount = 1 },
            [2] = { item = 'sulphur',  amount = 1 },
            
        },
        receive = 'ammo_repeater'
    },

    ['ammo_revolver'] = {
        name = 'ammo_revolver',
        lable = '左轮手枪子弹 (N)',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'wood',  amount = 1 },
            [2] = { item = 'sulphur',  amount = 1 },
            
        },
        receive = 'ammo_revolver'
    },

    ['ammo_rifle'] = {
        name = 'ammo_rifle',
        lable = '步枪子弹 (N)',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'wood',  amount = 1 },
            [2] = { item = 'sulphur',  amount = 1 },
            
        },
        receive = 'ammo_rifle'
    },

    ['ammo_rifle_elephant'] = {
        name = 'ammo_rifle_elephant',
        lable = '猎象步枪子弹 (N)',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'wood',  amount = 1 },
            [2] = { item = 'sulphur',  amount = 1 },
            
        },
        receive = 'ammo_rifle_elephant'
    },

    ['ammo_pistol'] = {
        name = 'ammo_pistol',
        lable = '手枪子弹 (N)',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'wood',  amount = 1 },
            [2] = { item = 'sulphur',  amount = 1 },
            
        },
        receive = 'ammo_pistol'
    },

    ['ammo_shotgun'] = {
        name = 'ammo_shotgun',
        lable = '霰弹枪子弹 (N)',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'wood',  amount = 1 },
            [2] = { item = 'sulphur',  amount = 1 },
            
        },
        receive = 'ammo_shotgun'
    },

    ['ammo_arrow'] = {
        name = 'ammo_arrow',
        lable = '箭矢 (N)',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'wood',  amount = 2 },
            
        },
        receive = 'ammo_arrow'
    },

    ['ammo_varmint'] = {
        name = 'ammo_varmint',
        lable = '22lr子弹 (N)',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'wood',  amount = 1 },
            [2] = { item = 'sulphur',  amount = 1 },
            
        },
        receive = 'ammo_varmint'
    },


    
}

Config.RifleCrafting = {
    
    -- 步枪制作
    ['weapon_rifle_boltaction'] = {
        name = 'weapon_rifle_boltaction',
        lable = '拉栓式步枪',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'trigger',  amount = 1 },
            [2] = { item = 'hammer',   amount = 1 },
            [3] = { item = 'barrel',   amount = 1 },
            [4] = { item = 'frame',    amount = 1 },
            [5] = { item = 'grip',     amount = 1 },
            [6] = { item = 'cylinder', amount = 1 },
        },
        receive = 'weapon_rifle_boltaction'
    },
}

Config.ShotgunCrafting = {
    
    -- 霰弹枪制作
   
}

Config.ToolsCrafting = {
    
    -- 工具制作
    ['weapon_lasso'] = {
        name = 'weapon_lasso',
        lable = '套索',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'poor_coyote_pelt',  amount = 10 },
        },
        receive = 'weapon_lasso'
    },

    ['weapon_melee_knife'] = {
        name = 'weapon_melee_knife',
        lable = '狩猎小刀',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'wood',  amount = 3 },
            [2] = { item = 'copper',   amount = 3 },
            [3] = { item = 'aluminum',   amount = 3 },
            [4] = { item = 'iron',    amount = 3 },
            [5] = { item = 'steel',     amount = 3 },
        },
        receive = 'weapon_melee_knife'
    },

    ['cleankit'] = {
        name = 'cleankit',
        lable = '枪械清洁工具',
        crafttime = 5000,
        craftitems = {
            [1] = { item = 'wood',  amount = 5 },
            [2] = { item = 'copper',   amount = 5 },
            [3] = { item = 'aluminum',   amount = 5 },
            [4] = { item = 'iron',    amount = 5 },
            [5] = { item = 'steel',     amount = 5 },
        },
        receive = 'cleankit'
    },
}
