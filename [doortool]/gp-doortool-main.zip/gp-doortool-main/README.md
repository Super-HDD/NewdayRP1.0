# gp-doortool
Simple standalone door tool, for viewing doorId and other info

# FEATURES
STANDALONE <br>
TURN ON/OFF DETAILS <br>
MINIMALISTIC SCRIPT <br>

# [PREVIEW](https://streamable.com/99dshj)
