Config = {}

-- debug
Config.Debug = true


